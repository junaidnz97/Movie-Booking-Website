var express=require("express");

var mysql = require('mysql');
var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "Ad_07_",
  database: "dbmsAssignment"
});

con.connect(function(err) {
  if (err) throw err;
  console.log('Connected to the database');

});

var app = express();
var bodyParser=require("body-parser");
//var urlencodedParser = bodyParser.urlencoded({ extended: false });
var jsonParser = bodyParser.json();

var server=app.listen("8080",function(){

	console.log("server working");
});

app.use("/public",express.static("public"));

app.set("view engine","ejs");



app.get("/",function(req,res){
	var seatDetails = con.query("select seat_no,status from screen",function(err,res) {
		if(err) throw err;
		console.log(res);
		return JSON.stringify(res);
});
	var data={rows:[1,2,3],
		cols:["A","B","C"],
		seatDetails
		 };
	res.render("main_page",{data:data});

});

app.get("/navbar",function(req,res){
	res.render("navbar");
	console.log("hello")
});


app.post("/booked",function(req,res){

	res.render("navbar");
	console.log(req.body);
});
